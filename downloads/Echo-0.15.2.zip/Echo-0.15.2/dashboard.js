(async()=>{
const pages=['inicio','academia','actividad','configuracion'];
const titles={inicio:'Tu espacio de apoyo',consejos:'Consejos para un uso responsable',academia:'Tu ruta de aprendizaje',recordatorios:'Tus recordatorios',actividad:'Tu progreso en Echo',configuracion:'Preferencias'};
const navButtons=[...document.querySelectorAll('.nav-btn')];
function showPage(name){
 if(!pages.includes(name))return;
 document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id==='page-'+name));
 navButtons.forEach(b=>b.classList.toggle('active',b.dataset.page===name));
 document.getElementById('pageContext').textContent=titles[name];
 document.body.classList.remove('menu-open');
 window.scrollTo({top:0,behavior:'smooth'});
}
navButtons.forEach(b=>b.addEventListener('click',()=>showPage(b.dataset.page)));
document.querySelectorAll('[data-go]').forEach(b=>b.addEventListener('click',()=>showPage(b.dataset.go)));
document.getElementById('menuToggle').addEventListener('click',()=>document.body.classList.toggle('menu-open'));
document.getElementById('overlay').addEventListener('click',()=>document.body.classList.remove('menu-open'));

const storageKey='aldenPrototype03';
let data={reviewed:[],reminders:true,name:''};
const stored=await chrome.storage.local.get([storageKey,'reminders']); data={...data,...stored[storageKey],reminders:stored.reminders??true};
let pendingSave=Promise.resolve(); function save(){const snapshot={...data};pendingSave=pendingSave.catch(()=>{}).then(()=>chrome.storage.local.set({[storageKey]:snapshot}));pendingSave.catch(console.error);return pendingSave;}
function setReminder(value){data.reminders=value;document.getElementById('settingsToggle').checked=value;for(const id of ['tipDuration'])document.getElementById(id).disabled=!value;document.getElementById('reminderStatus').textContent=value?'Activados.':'Desactivados.';}
document.getElementById('settingsToggle').addEventListener('change',e=>changeReminders(e.target.checked));
for(const id of ['tipDuration'])document.getElementById(id).addEventListener('change',async e=>{try{await chrome.storage.local.set({[id]:Number(e.target.value)});document.getElementById('reminderStatus').textContent='Preferencia guardada.'}catch{document.getElementById('reminderStatus').textContent='No se pudo guardar.';await refreshAI()}});
document.getElementById('displayName').value=data.name||'';
document.getElementById('saveSettings').addEventListener('click',()=>{
 data.name=document.getElementById('displayName').value.trim();save();
 document.getElementById('settingsMessage').textContent='Tus cambios se guardaron en este navegador.';
});
const el=id=>document.getElementById(id);
data.lessons=Array.isArray(data.lessons)?data.lessons.filter(x=>Number.isInteger(x)&&x>=0&&x<9&&x!==1):[];
function lessonStats(){el('lessonProgress').textContent=`${data.lessons.length} de 8 módulos completados`;el('lessonBar').style.width=(data.lessons.length*12.5)+'%';el('activityLessons').textContent=el('lessonProgress').textContent;el('activityBar').style.width=el('lessonBar').style.width;}
document.querySelectorAll('[data-lesson]').forEach(c=>{const n=Number(c.dataset.lesson);c.checked=data.lessons.includes(n);c.addEventListener('change',()=>{data.lessons=c.checked?[...new Set([...data.lessons,n])]:data.lessons.filter(x=>x!==n);save();lessonStats();});});
lessonStats();


setReminder(data.reminders);

async function changeReminders(value){try{await chrome.runtime.sendMessage({type:'reminders',value});setReminder(value)}catch(e){el('aiStatus').textContent='No se pudo guardar la preferencia.';await refreshAI()}}
function dateKey(d){return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`}
function duration(s){s=Math.floor(s);return `${Math.floor(s/3600)?Math.floor(s/3600)+' h ':''}${Math.floor(s%3600/60)} min ${s%60} s`}
async function refreshAI(){const {stats={},tracking=false,reminders=true,tipDuration=8}=await chrome.storage.local.get(['stats','tracking','reminders','tipDuration']);setReminder(reminders);el('tipDuration').value=tipDuration;el('trackingMain').checked=tracking;el('trackingState').textContent=tracking?'Registro activo':'Registro desactivado';const n=Number(el('periodMain').value),d=new Date();d.setDate(d.getDate()-Math.max(0,n-1));const first=dateKey(d),last=dateKey(new Date()), totals={};for(const [day,sites] of Object.entries(stats)){if(n&&(day<first||day>last))continue;for(const [p,a] of Object.entries(sites)){totals[p]??={seconds:0,visits:0};totals[p].seconds+=a.seconds;totals[p].visits+=a.visits;}}let s=0,v=0;const root=el('aiPlatforms');root.replaceChildren();for(const [p,a] of Object.entries(totals).sort((a,b)=>b[1].seconds-a[1].seconds)){s+=a.seconds;v+=a.visits;const row=document.createElement('p');row.textContent=`${p} · ${duration(a.seconds)} · ${a.visits} accesos`;root.append(row)}el('aiTime').textContent=duration(s);el('aiVisits').textContent=v;el('aiStatus').textContent=Object.keys(totals).length?'Datos locales; se actualizan automáticamente.':tracking?'Todavía no hay actividad en este periodo.':'Activa el registro si deseas consultar tu actividad.';}
el('periodMain').addEventListener('change',refreshAI);el('trackingMain').addEventListener('change',async e=>{await chrome.runtime.sendMessage({type:'tracking',value:e.target.checked});await refreshAI()});el('resetMain').addEventListener('click',async()=>{if(confirm('¿Eliminar todas las estadísticas de IA? Tu aprendizaje se conservará.')){await chrome.runtime.sendMessage({type:'reset'});await refreshAI()}});chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&storageKey in changes){const incoming=changes[storageKey].newValue;if(incoming&&JSON.stringify(incoming)!==JSON.stringify(data)){data={...incoming,lessons:[...new Set((incoming.lessons||[]).filter(x=>Number.isInteger(x)&&x>=0&&x<9&&x!==1))]};document.querySelectorAll('[data-lesson]').forEach(c=>c.checked=(data.lessons||[]).includes(Number(c.dataset.lesson)));el('displayName').value=data.name||'';lessonStats();}}if(area==='local'&&['stats','tracking','reminders','tipDuration'].some(k=>k in changes))refreshAI()});await chrome.runtime.sendMessage({type:'refresh'});await refreshAI();
const backupStatus=el('backupStatus');
function backupBusy(b){el('exportBackup').disabled=b;el('importBackup').disabled=b;}
el('exportBackup').onclick=async()=>{backupBusy(true);try{
 await pendingSave;await chrome.runtime.sendMessage({type:'refresh'});
 const stored=await chrome.storage.local.get([storageKey,'stats','tracking','reminders','tipDuration']);const l=stored[storageKey]||{};
 const backup={format:'echo-backup',version:1,createdAt:new Date().toISOString(),data:{learning:{lessons:l.lessons||[],name:l.name||''},stats:stored.stats||{},tracking:stored.tracking??false,reminders:stored.reminders??true,tipDuration:stored.tipDuration??8}};
 validateBackup(backup);const blob=new Blob([JSON.stringify(backup,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='echo-copia-'+dateKey(new Date())+'.json';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);backupStatus.textContent='Copia preparada. Comprueba la carpeta de descargas y conserva el archivo en un lugar seguro.';
 }catch(e){backupStatus.textContent='No se pudo generar la copia: '+e.message;}finally{backupBusy(false);}};
el('importBackup').onclick=()=>el('backupFile').click();
el('backupFile').onchange=async()=>{const file=el('backupFile').files[0];if(!file)return;backupBusy(true);try{
 if(file.size>15*1024*1024)throw new Error('El archivo supera el límite de 15 MB.');const backup=JSON.parse(await file.text());validateBackup(backup);
 if(!confirm('¿Restaurar esta copia? Se reemplazarán tu progreso, estadísticas y preferencias actuales. Si quieres conservarlos, cancela y genera primero una copia.'))return;
 await pendingSave;const result=await chrome.runtime.sendMessage({type:'restoreBackup',backup});if(!result?.ok)throw new Error(result?.error||'No se pudo restaurar la copia.');sessionStorage.setItem('echoBackupRestored','1');location.reload();
 }catch(e){backupStatus.textContent='No se pudo restaurar: '+e.message;}finally{el('backupFile').value='';backupBusy(false);}};
if(sessionStorage.getItem('echoBackupRestored')){sessionStorage.removeItem('echoBackupRestored');backupStatus.textContent='¡Copia restaurada! Tu progreso y preferencias están disponibles.';}
if(location.hash==='#actividad')showPage('actividad');

})().catch(e=>{console.error(e);document.getElementById("aiStatus").textContent="No se pudo cargar Echo."});