// Shared validation: only portable, explicitly allowed fields are restored.
function validateBackup(b) {
 const fail=()=>{throw new Error('El archivo no es una copia de Echo válida o compatible.')};
 const obj=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
 const count=x=>Number.isSafeInteger(x)&&x>=0;
 const ids=(x,max)=>Array.isArray(x)&&x.every(v=>count(v)&&v<max);
 if(!obj(b)||b.format!=='echo-backup'||b.version!==1||!obj(b.data))fail();
 const {learning:l,stats,tracking,reminders,tipDuration=8}=b.data;
 if(!obj(l)||(l.reviewed!==undefined&&!ids(l.reviewed,6))||![5,8,15].includes(tipDuration)||!ids(l.lessons,9)||typeof l.name!=='string'||l.name.length>10000||typeof tracking!=='boolean'||typeof reminders!=='boolean'||!obj(stats))fail();
 const clean={}; const platforms=['ChatGPT','Gemini','Claude','Copilot','DeepSeek','Perplexity'];
 for(const [date,sites] of Object.entries(stats)){
  if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||!Number.isFinite(Date.parse(date))||new Date(date).toISOString().slice(0,10)!==date||!obj(sites))fail();
  clean[date]={};for(const [p,a] of Object.entries(sites)){
   if(!platforms.includes(p)||!obj(a)||typeof a.seconds!=='number'||!Number.isFinite(a.seconds)||a.seconds<0||a.seconds>Number.MAX_SAFE_INTEGER||!count(a.visits))fail();
   clean[date][p]={seconds:a.seconds,visits:a.visits};
  }
 }
 return {aldenPrototype03:{lessons:[...new Set(l.lessons.filter(x=>x!==1))],name:l.name,reminders},stats:clean,tracking,reminders,tipDuration};
}
